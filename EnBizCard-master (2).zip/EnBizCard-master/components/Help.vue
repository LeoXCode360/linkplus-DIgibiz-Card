<template>
  <div id="help" class="mt-16">
    <h2 class="font-extrabold text-2xl">
      Having issues, suggestions and feedback?
    </h2>
    <div class="stepC mt-6">
      <div class="flex items-center mt-6">
        <a
          href="https://t.me/enbizcard"
          target="_blank"
          class="flex items-center text-lg leading-none p-5 shrink-0 rounded cursor-pointer border-2 border-transparent bg-gray-700 text-white hover:bg-gray-600 focus:bg-gray-600 transition-colors duration-200 font-extrabold"
          rel="noreferrer"
        >
          Join the Telegram group
        </a>
      </div>
    </div>
  </div>
</template>