export class PDFViewer extends BaseViewer {
}
import { BaseViewer } from "./base_viewer.js";
