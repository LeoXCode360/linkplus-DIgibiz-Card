export const viewerCompatibilityParams: any;
