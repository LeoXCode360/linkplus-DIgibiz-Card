/**
 * @type {any}
 */
export const CanvasGraphics: any;
