export const isNodeJS: boolean;
