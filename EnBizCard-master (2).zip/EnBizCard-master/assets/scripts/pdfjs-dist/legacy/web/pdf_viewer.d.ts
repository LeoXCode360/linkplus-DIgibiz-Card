export * from "pdfjs-dist/types/web/pdf_viewer.component.d.ts";
